What? You're actually reading the docs? Er, ok, here we go:

This is just a little app that gets weather stats from around the world. It is written in Python 3.6 and frozen (packaged) into a Windows executable with TKinter.

Extract the archive into any folder (desktop or temp is fine; you won't be keeping this fucking thing anyway). Run the executable EricsShittyWeatherApp.exe. 

Type any valid city name or postal code, followed by country code (So, US for 'Merica, IT for Italy, etc) and click "Get Weather". Caveat: For larger cities the country code is not usually required.
